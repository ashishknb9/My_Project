export interface User {
    id: number;
    title: string;
    body: string;
    name:string;
    email:string;
    phone:string;
    address:string;
}
