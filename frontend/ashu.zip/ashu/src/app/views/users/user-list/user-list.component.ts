import { Component, OnInit } from '@angular/core';
import { UserService } from '../../user.service';
import { User } from '../../user';

@Component({
  selector: 'app-user-list',
  templateUrl: './user-list.component.html',
  styleUrls: ['./user-list.component.scss']
})
export class UserListComponent implements OnInit {

  users: User[] = [];
   
  constructor(public userService: UserService) { }
    
  ngOnInit(): void {
    this.userService.getAll().subscribe((data: User[])=>{
    this.users = data;
      console.log(this.users);
    })  
  }

}
