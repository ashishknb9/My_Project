import { Component, OnInit } from '@angular/core';
import { UserService } from '../../user.service';
//import { Router } from '@angular/router';
import { FormGroup,FormControl,Validators } from '@angular/forms';

@Component({
  selector: 'app-create-user',
  templateUrl: './create-user.component.html',
  styleUrls: ['./create-user.component.scss']
})
export class CreateUserComponent implements OnInit {

  form: FormGroup;
   
  constructor(
    public userService: UserService,
  //  private router: Router
  ) { }
  
  ngOnInit(): void {
    this.form = new FormGroup({
      name: new FormControl('', Validators.required),
      phone: new FormControl('', Validators.required),
      email: new FormControl('', Validators.email),
      address: new FormControl('', Validators.required)
    });
  }
   
  get f(){
    return this.form.controls;
  }
    
  submit(){
    
    this.userService.create(this.form.value).subscribe(_res => {
      console.log(_res);
         console.log('User created successfully!');
        // this.router.navigateByUrl('post/index');
    })
  }

}
